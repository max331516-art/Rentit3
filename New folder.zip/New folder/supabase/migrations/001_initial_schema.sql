-- ════════════════════════════════════════════════════════════════════════════
-- RentIt — полная миграция базы данных
-- Выполни этот SQL в Supabase Dashboard → SQL Editor → New query → Run
-- ════════════════════════════════════════════════════════════════════════════

create extension if not exists "uuid-ossp";

-- PROFILES
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  name          text not null,
  phone         text,
  avatar_url    text,
  telegram_id   bigint unique,
  telegram_username text,
  rating        numeric(3,2) default 0,
  rentals_count int default 0,
  listings_count int default 0,
  created_at    timestamptz default now()
);
alter table public.profiles enable row level security;
create policy "Profiles viewable by everyone" on public.profiles for select using (true);
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users insert own profile" on public.profiles for insert with check (auth.uid() = id);

-- ITEMS
create table if not exists public.items (
  id            uuid primary key default uuid_generate_v4(),
  owner_id      uuid not null references public.profiles(id) on delete cascade,
  title         text not null,
  category      text not null,
  description   text,
  price_per_day int not null,
  deposit       int not null default 0,
  min_days      int not null default 1,
  images        text[] default '{}',
  location      text,
  condition     text not null default 'Хорошее',
  available     boolean default true,
  rating        numeric(3,2) default 0,
  reviews_count int default 0,
  created_at    timestamptz default now()
);
alter table public.items enable row level security;
create policy "Items viewable by everyone" on public.items for select using (true);
create policy "Auth users create items" on public.items for insert with check (auth.uid() = owner_id);
create policy "Owners update items" on public.items for update using (auth.uid() = owner_id);
create policy "Owners delete items" on public.items for delete using (auth.uid() = owner_id);

-- BOOKINGS
create table if not exists public.bookings (
  id            uuid primary key default uuid_generate_v4(),
  item_id       uuid not null references public.items(id) on delete cascade,
  item_title    text not null,
  item_image    text,
  renter_id     uuid not null references public.profiles(id),
  owner_id      uuid not null references public.profiles(id),
  start_date    date not null,
  end_date      date not null,
  days          int not null,
  price_per_day int not null,
  deposit       int not null default 0,
  total_rent    int not null,
  platform_fee  int not null,
  total_amount  int not null,
  status        text not null default 'pending'
                check (status in ('pending','confirmed','active','returned','cancelled','disputed')),
  created_at    timestamptz default now()
);
alter table public.bookings enable row level security;
create policy "Renter or owner see bookings" on public.bookings for select using (auth.uid() = renter_id or auth.uid() = owner_id);
create policy "Auth users create bookings" on public.bookings for insert with check (auth.uid() = renter_id);
create policy "Renter or owner update booking" on public.bookings for update using (auth.uid() = renter_id or auth.uid() = owner_id);

-- REVIEWS
create table if not exists public.reviews (
  id            uuid primary key default uuid_generate_v4(),
  booking_id    uuid not null references public.bookings(id) on delete cascade,
  item_id       uuid not null references public.items(id) on delete cascade,
  reviewer_id   uuid not null references public.profiles(id),
  rating        int not null check (rating between 1 and 5),
  text          text not null,
  created_at    timestamptz default now(),
  unique (booking_id, reviewer_id)
);
alter table public.reviews enable row level security;
create policy "Reviews viewable by everyone" on public.reviews for select using (true);
create policy "Auth users create reviews" on public.reviews for insert with check (auth.uid() = reviewer_id);

-- MESSAGES (Built-in Chat)
create table if not exists public.messages (
  id            uuid primary key default uuid_generate_v4(),
  booking_id    uuid not null references public.bookings(id) on delete cascade,
  sender_id     uuid not null references public.profiles(id),
  text          text not null,
  created_at    timestamptz default now()
);
alter table public.messages enable row level security;
create policy "Users see messages in their bookings" on public.messages for select using (
  exists (
    select 1 from public.bookings b 
    where b.id = messages.booking_id and (b.renter_id = auth.uid() or b.owner_id = auth.uid())
  )
);
create policy "Users send messages" on public.messages for insert with check (
  auth.uid() = sender_id and exists (
    select 1 from public.bookings b 
    where b.id = messages.booking_id and (b.renter_id = auth.uid() or b.owner_id = auth.uid())
  )
);

-- STORAGE BUCKET для фото вещей
insert into storage.buckets (id, name, public) values ('item-photos', 'item-photos', true) on conflict (id) do nothing;
create policy "Anyone view item photos" on storage.objects for select using (bucket_id = 'item-photos');
create policy "Auth upload item photos" on storage.objects for insert with check (bucket_id = 'item-photos' and auth.role() = 'authenticated');
create policy "Delete own photos" on storage.objects for delete using (bucket_id = 'item-photos' and auth.uid()::text = (storage.foldername(name))[1]);

-- TRIGGER: профиль при регистрации
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, name, phone, telegram_id, telegram_username)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1), 'Пользователь'),
    new.raw_user_meta_data->>'phone',
    (new.raw_user_meta_data->>'telegram_id')::bigint,
    new.raw_user_meta_data->>'telegram_username'
  ) on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- TRIGGER: рейтинг вещи
create or replace function public.update_item_rating()
returns trigger language plpgsql security definer as $$
declare new_avg numeric; new_count int;
begin
  select round(avg(rating)::numeric, 2), count(*)::int into new_avg, new_count from public.reviews where item_id = new.item_id;
  update public.items set rating = new_avg, reviews_count = new_count where id = new.item_id;
  return new;
end;
$$;
drop trigger if exists on_review_created on public.reviews;
create trigger on_review_created after insert on public.reviews for each row execute function public.update_item_rating();

-- TRIGGER: счётчик объявлений
create or replace function public.update_listings_count()
returns trigger language plpgsql security definer as $$
begin
  if TG_OP = 'INSERT' then update public.profiles set listings_count = listings_count + 1 where id = new.owner_id;
  elsif TG_OP = 'DELETE' then update public.profiles set listings_count = greatest(0, listings_count - 1) where id = old.owner_id;
  end if;
  return coalesce(new, old);
end;
$$;
drop trigger if exists on_item_change on public.items;
create trigger on_item_change after insert or delete on public.items for each row execute function public.update_listings_count();
