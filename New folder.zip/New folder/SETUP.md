# RentIt — Полная инструкция по запуску

## ШАГ 1: SQL миграция в Supabase (ОБЯЗАТЕЛЬНО)

Без этого шага приложение не работает.

### 1.1 Открой Supabase Dashboard
https://supabase.com/dashboard/project/igzimnqitkhnuvgtlvgt

### 1.2 Открой SQL Editor
В левом меню → "SQL Editor" → "New query"

### 1.3 Выполни миграцию
1. Открой файл: supabase/migrations/001_initial_schema.sql
2. Скопируй ВСЁ содержимое (Ctrl+A, Ctrl+C)
3. Вставь в SQL Editor (Ctrl+V)
4. Нажми "Run" (или Ctrl+Enter)
5. Увидишь "Success. No rows returned" — всё правильно!

### 1.4 Проверь
Table Editor → должны появиться: profiles, items, bookings, reviews
Storage → должен появиться bucket: item-photos

---

## ШАГ 2: Запуск приложения

npm install
npm run dev

Открой http://localhost:5173
При первом входе 9 демо-объявлений добавятся автоматически.

---

## ШАГ 3: Деплой для Telegram Mini App

TMA требует публичный HTTPS домен. Проще всего — Vercel.

npm install -g vercel
vercel --prod
Получишь URL: https://rentit-xxx.vercel.app

В Vercel Dashboard → Settings → Environment Variables добавь:
VITE_SUPABASE_URL = https://igzimnqitkhnuvgtlvgt.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY = (из файла .env)

В Supabase → Authentication → URL Configuration:
Site URL: https://rentit-xxx.vercel.app
Redirect URLs: https://rentit-xxx.vercel.app/**

---

## ШАГ 4: Настройка Telegram Mini App

### Создай бота
1. Telegram → @BotFather → /newbot
2. Название: RentIt
3. Username: rentit_app_bot
4. Сохрани токен

### Создай Mini App
В @BotFather:
1. /newapp → выбери бота
2. Название: RentIt аренда вещей
3. URL: https://rentit-xxx.vercel.app
4. Получишь ссылку: t.me/rentit_app_bot/app

### Настрой кнопку меню
/mybots → бот → Bot Settings → Menu Button
Текст: Открыть RentIt
URL: https://rentit-xxx.vercel.app

---

## Что работает

Web App:
- Регистрация / Вход (email + пароль)
- Загрузка фото с устройства (Supabase Storage)
- Каталог с фильтрацией, поиском, сортировкой
- Бронирование с выбором дат и расчётом стоимости
- Lifecycle брони: pending → confirmed → active → returned
- Симуляция оплаты
- Отзывы с автопересчётом рейтинга
- Личный кабинет

В Telegram Mini App дополнительно:
- Автовход через Telegram (без email/пароля!)
- Нижняя навигация вместо навбара
- Haptic feedback
- Адаптация под цветовую схему Telegram

---

## Частые ошибки

"Could not find table public.items"
→ Выполни SQL миграцию (Шаг 1)

"Upload error" при загрузке фото
→ В SQL есть строка про storage.buckets — убедись что миграция выполнена полностью

В TMA не авторизует автоматически
→ Убедись что открываешь через t.me/бот/app, а не обычную ссылку
