// Re-export from unified supabase module
export { supabase } from '@/lib/supabase';
