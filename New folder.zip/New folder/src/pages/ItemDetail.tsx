import { useParams, Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Shield, Camera, ArrowLeft, Calendar, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import { getItemById, getReviewsByItem, createBooking, isItemAvailable, type Item, type Review } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

const ItemDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [authOpen, setAuthOpen] = useState(false);
  const [booking, setBooking] = useState(false);
  const [imgIdx, setImgIdx] = useState(0);

  const { data: itemData, isLoading: loadingItem } = useQuery({
    queryKey: ['item', id],
    queryFn: async () => {
      if (!id) return null;
      const { data, error } = await getItemById(id);
      if (error) throw error;
      return data;
    },
    enabled: !!id
  });

  const { data: reviewsData } = useQuery({
    queryKey: ['reviews', id],
    queryFn: async () => {
      if (!id) return [];
      const { data, error } = await getReviewsByItem(id);
      if (error) throw error;
      return data;
    },
    enabled: !!id
  });

  const item = itemData || null;
  const reviews = reviewsData || [];

  if (loadingItem) return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <Link to="/catalog" className="mb-6 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />Назад в каталог
        </Link>
        <div className="grid gap-8 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <Skeleton className="aspect-[4/3] w-full rounded-xl" />
            <div className="mt-8">
              <Skeleton className="h-8 w-48 mb-4" />
              <div className="space-y-4">
                {[1, 2].map(i => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}
              </div>
            </div>
          </div>
          <div className="lg:col-span-2 space-y-4">
            <Skeleton className="h-6 w-24" />
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-24 w-full mt-4" />
            <Skeleton className="h-48 w-full mt-6 rounded-xl" />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );

  if (!item) return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-20 text-center">
        <h1 className="text-2xl font-bold">Вещь не найдена</h1>
        <Link to="/catalog"><Button className="mt-4" variant="outline">В каталог</Button></Link>
      </div>
      <Footer />
    </div>
  );

  const today = new Date().toISOString().slice(0, 10);
  const days = startDate && endDate ? Math.max(0, Math.round((new Date(endDate).getTime() - new Date(startDate).getTime()) / 86400000)) : 0;
  const totalRent = days * item.price_per_day;
  const platformFee = Math.round(totalRent * 0.15);
  const total = totalRent + platformFee + item.deposit;

  const handleBook = async () => {
    if (!user) { setAuthOpen(true); return; }
    if (user.id === item.owner_id) { toast({ title: 'Нельзя арендовать свою вещь', variant: 'destructive' }); return; }
    if (!startDate || !endDate) { toast({ title: 'Выберите даты аренды', variant: 'destructive' }); return; }
    if (days < item.min_days) { toast({ title: `Минимальный срок — ${item.min_days} дн.`, variant: 'destructive' }); return; }

    setBooking(true);
    const available = await isItemAvailable(item.id, startDate, endDate);
    if (!available) { toast({ title: 'Вещь занята на эти даты', variant: 'destructive' }); setBooking(false); return; }

    const { data: bk, error } = await createBooking({
      item_id: item.id, item_title: item.title, item_image: item.images[0] || null,
      renter_id: user.id, owner_id: item.owner_id,
      start_date: startDate, end_date: endDate, days,
      price_per_day: item.price_per_day, deposit: item.deposit,
      total_rent: totalRent, platform_fee: platformFee, total_amount: total,
      status: 'pending',
    });
    setBooking(false);
    if (error || !bk) { toast({ title: 'Ошибка создания брони', description: error?.message, variant: 'destructive' }); return; }
    navigate(`/booking/${bk.id}`);
  };

  return (
    <div className="min-h-screen bg-background animate-in fade-in duration-500">
      <Navbar />
      <div className="container py-8">
        <Link to="/catalog" className="mb-6 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />Назад в каталог
        </Link>
        <div className="grid gap-8 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-muted">
              <img src={item.images[imgIdx] || '/placeholder.svg'} alt={item.title} className="h-full w-full object-cover" onError={e => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }} />
              {item.images.length > 1 && (
                <>
                  <button onClick={() => setImgIdx(i => (i - 1 + item.images.length) % item.images.length)} className="absolute left-3 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-card/80 backdrop-blur-sm"><ChevronLeft className="h-4 w-4" /></button>
                  <button onClick={() => setImgIdx(i => (i + 1) % item.images.length)} className="absolute right-3 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-card/80 backdrop-blur-sm"><ChevronRight className="h-4 w-4" /></button>
                </>
              )}
            </div>
            {reviews.length > 0 && (
              <div className="mt-8">
                <h2 className="font-display text-xl font-bold">Отзывы ({reviews.length})</h2>
                <div className="mt-4 space-y-4">
                  {reviews.map(rv => (
                    <div key={rv.id} className="rounded-xl border bg-card p-4 card-shadow">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-sm">{(rv.reviewer?.name ?? 'А').charAt(0)}</div>
                        <div>
                          <div className="text-sm font-medium">{rv.reviewer?.name ?? 'Аноним'}</div>
                          <div className="flex gap-0.5">{Array.from({length:5}).map((_,i) => <Star key={i} className={`h-3.5 w-3.5 ${i < rv.rating ? 'fill-accent text-accent' : 'text-muted'}`} />)}</div>
                        </div>
                        <span className="ml-auto text-xs text-muted-foreground">{rv.created_at.slice(0,10)}</span>
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground">{rv.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-2">
            <Badge variant="secondary">{item.condition}</Badge>
            <h1 className="mt-3 font-display text-2xl font-bold md:text-3xl">{item.title}</h1>
            <div className="mt-2 flex items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-accent text-accent" />{item.rating > 0 ? `${item.rating} (${item.reviews_count} отзывов)` : 'Нет отзывов'}</span>
              <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{item.location}</span>
            </div>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">{item.description}</p>

            <div className="mt-6 rounded-xl border bg-card p-5 card-shadow">
              <div className="flex items-baseline justify-between">
                <div><span className="text-3xl font-bold">{item.price_per_day} ₽</span><span className="text-muted-foreground"> / сутки</span></div>
                <span className="text-sm text-muted-foreground">мин. {item.min_days} дн.</span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Начало</label>
                  <input type="date" value={startDate} min={today} onChange={e => { setStartDate(e.target.value); if (endDate && e.target.value > endDate) setEndDate(''); }} className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Конец</label>
                  <input type="date" value={endDate} min={startDate || today} onChange={e => setEndDate(e.target.value)} className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
              </div>
              {days > 0 && (
                <div className="mt-4 space-y-2 text-sm border-t pt-4">
                  <div className="flex justify-between"><span className="text-muted-foreground">{item.price_per_day} ₽ × {days} дн.</span><span className="font-medium">{totalRent.toLocaleString()} ₽</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Комиссия 15%</span><span className="font-medium">{platformFee.toLocaleString()} ₽</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Депозит (возврат)</span><span className="font-medium">{item.deposit.toLocaleString()} ₽</span></div>
                  <div className="flex justify-between border-t pt-2 font-bold"><span>Итого</span><span>{total.toLocaleString()} ₽</span></div>
                </div>
              )}
              <Button onClick={handleBook} disabled={booking} size="lg" className="mt-5 w-full bg-primary text-primary-foreground hover:bg-primary/90">
                {booking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Calendar className="mr-2 h-5 w-5" />}
                {user ? 'Забронировать' : 'Войдите для бронирования'}
              </Button>
              <div className="mt-3 flex items-center justify-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Shield className="h-3.5 w-3.5 text-primary" />Депозит защищён</span>
                <span className="flex items-center gap-1"><Camera className="h-3.5 w-3.5 text-primary" />Фотофиксация</span>
              </div>
            </div>

            {item.owner && (
              <div className="mt-5 flex items-center gap-3 rounded-xl border bg-card p-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary font-bold">{item.owner.name.charAt(0)}</div>
                <div>
                  <div className="text-sm font-medium">{item.owner.name}</div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {item.owner.rating > 0 && <span className="flex items-center gap-0.5"><Star className="h-3 w-3 fill-accent text-accent" />{item.owner.rating}</span>}
                    <span>· {item.owner.rentals_count} аренд</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
    </div>
  );
};
export default ItemDetail;