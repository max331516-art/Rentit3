import { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Loader2, Upload, X, ImagePlus, MapPin } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import MapPicker from '@/components/MapPicker';
import { createItem, uploadItemPhoto } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const CATEGORIES = [
  { id: 'tools', name: 'Инструменты', icon: '🔧' },
  { id: 'sports', name: 'Спорт', icon: '⚽' },
  { id: 'kids', name: 'Детские товары', icon: '👶' },
  { id: 'events', name: 'Для мероприятий', icon: '🎉' },
  { id: 'electronics', name: 'Техника', icon: '📷' },
  { id: 'household', name: 'Бытовая техника', icon: '🏠' },
];

const CreateListing = () => {
  const { user, isTMA } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [authOpen, setAuthOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [category, setCategory] = useState('');
  const [condition, setCondition] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [pricePerDay, setPricePerDay] = useState('');
  const [deposit, setDeposit] = useState('');
  const [minDays, setMinDays] = useState('1');
  const [location, setLocation] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!user) { setAuthOpen(true); return; }
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    if (photos.length + files.length > 5) {
      toast({ title: 'Максимум 5 фото', variant: 'destructive' }); return;
    }

    setUploadingPhoto(true);
    for (const file of files) {
      if (file.size > 10 * 1024 * 1024) {
        toast({ title: `${file.name} слишком большой (макс. 10 МБ)`, variant: 'destructive' });
        continue;
      }
      const url = await uploadItemPhoto(file, user.id);
      if (url) setPhotos(prev => [...prev, url]);
      else toast({ title: 'Ошибка загрузки фото', variant: 'destructive' });
    }
    setUploadingPhoto(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removePhoto = (url: string) => {
    setPhotos(prev => prev.filter(p => p !== url));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { 
      setAuthOpen(true); 
      toast({ title: 'Необходима авторизация', description: 'Пожалуйста, войдите в аккаунт, чтобы создать объявление.', variant: 'destructive' });
      return; 
    }
    if (!confirmed) { toast({ title: 'Подтвердите состояние вещи', variant: 'destructive' }); return; }
    if (!category || !condition) { toast({ title: 'Выберите категорию и состояние', variant: 'destructive' }); return; }
    if (photos.length === 0) { toast({ title: 'Добавьте хотя бы одно фото', variant: 'destructive' }); return; }

    setLoading(true);
    const { data, error } = await createItem({
      owner_id: user.id,
      title, category, description,
      price_per_day: Number(pricePerDay),
      deposit: Number(deposit),
      min_days: Number(minDays),
      images: photos,
      location, condition, available: true,
    });
    setLoading(false);

    if (error || !data) {
      toast({ title: 'Ошибка публикации', description: error?.message, variant: 'destructive' }); return;
    }
    toast({ title: 'Объявление создано!', description: 'Ваша вещь теперь в каталоге.' });
    navigate(`/item/${data.id}`);
  };

  return (
    <div className="min-h-screen bg-background">
      {!isTMA && <Navbar />}
      <div className="container max-w-2xl py-8">
        {!isTMA && (
          <Link to="/catalog" className="mb-6 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-1 h-4 w-4" />Назад
          </Link>
        )}
        <h1 className="font-display text-3xl font-bold">Сдать вещь в аренду</h1>
        <p className="mt-2 text-muted-foreground">Заполните информацию о вещи.</p>

        <form onSubmit={handleSubmit} className="mt-8 space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Название</Label>
            <Input id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="Перфоратор Bosch GBH 2-26" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Категория</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue placeholder="Выберите" /></SelectTrigger>
                <SelectContent>{CATEGORIES.map(c => <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Состояние</Label>
              <Select value={condition} onValueChange={setCondition}>
                <SelectTrigger><SelectValue placeholder="Выберите" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Отличное">Отличное</SelectItem>
                  <SelectItem value="Хорошее">Хорошее</SelectItem>
                  <SelectItem value="Удовлетворительное">Удовлетворительное</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Описание</Label>
            <Textarea id="description" value={description} onChange={e => setDescription(e.target.value)} placeholder="Опишите вещь, комплектацию, особенности" rows={4} required />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Цена/сутки (₽)</Label>
              <Input type="number" min={1} value={pricePerDay} onChange={e => setPricePerDay(e.target.value)} placeholder="500" required />
            </div>
            <div className="space-y-2">
              <Label>Депозит (₽)</Label>
              <Input type="number" min={0} value={deposit} onChange={e => setDeposit(e.target.value)} placeholder="5000" required />
            </div>
            <div className="space-y-2">
              <Label>Мин. дней</Label>
              <Input type="number" min={1} value={minDays} onChange={e => setMinDays(e.target.value)} placeholder="1" required />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" /> Местоположение
            </Label>
            <Input value={location} onChange={e => setLocation(e.target.value)} placeholder="Москва, м. Таганская" required />
            <div className="mt-4">
              <MapPicker onLocationSelect={setLocation} />
            </div>
          </div>

          {/* Photo upload */}
          <div className="space-y-2">
            <Label>Фото вещи (до 5 штук)</Label>
            <div className="flex flex-wrap gap-3">
              {/* Existing photos */}
              {photos.map((url, i) => (
                <div key={i} className="relative h-24 w-24 rounded-xl overflow-hidden border bg-muted group">
                  <img src={url} alt={`фото ${i+1}`} className="h-full w-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removePhoto(url)}
                    className="absolute top-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-white opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}

              {/* Upload button */}
              {photos.length < 5 && (
                <button
                  type="button"
                  onClick={() => user ? fileInputRef.current?.click() : setAuthOpen(true)}
                  disabled={uploadingPhoto}
                  className="flex h-24 w-24 flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-border bg-muted/50 text-muted-foreground transition-colors hover:border-primary hover:text-primary hover:bg-primary/5"
                >
                  {uploadingPhoto ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    <>
                      <ImagePlus className="h-6 w-6" />
                      <span className="text-xs font-medium">Загрузить</span>
                    </>
                  )}
                </button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">JPG, PNG, WEBP — до 10 МБ каждое</p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handlePhotoSelect}
            />
          </div>

          <div className="flex items-start gap-3 rounded-xl border bg-card p-4">
            <Checkbox id="confirm" checked={confirmed} onCheckedChange={v => setConfirmed(!!v)} className="mt-0.5" />
            <Label htmlFor="confirm" className="text-sm leading-relaxed cursor-pointer">
              Подтверждаю, что вещь находится в описанном состоянии и готова к сдаче в аренду.
            </Label>
          </div>

          <Button type="submit" size="lg" className="w-full bg-primary text-primary-foreground" disabled={loading || uploadingPhoto}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {user ? 'Опубликовать объявление' : 'Войдите для публикации'}
          </Button>
        </form>
      </div>
      {!isTMA && <Footer />}
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
    </div>
  );
};
export default CreateListing;