import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ItemCard from '@/components/ItemCard';
import { getItems, type Item } from '@/lib/supabase';
import { Skeleton } from '@/components/ui/skeleton';

const CATEGORIES = [
  { id: 'tools', name: 'Инструменты', icon: '🔧' },
  { id: 'sports', name: 'Спорт', icon: '⚽' },
  { id: 'kids', name: 'Детские товары', icon: '👶' },
  { id: 'events', name: 'Для мероприятий', icon: '🎉' },
  { id: 'electronics', name: 'Техника', icon: '📷' },
  { id: 'household', name: 'Бытовая техника', icon: '🏠' },
];

const Catalog = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get('category') || 'all';
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'created_at' | 'price_per_day' | 'rating'>('created_at');
  const [sortAsc, setSortAsc] = useState(false);
  const [maxPrice, setMaxPrice] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const { data: items = [], isLoading: loading } = useQuery({
    queryKey: ['items', activeCategory, search, maxPrice, sortBy, sortAsc],
    queryFn: async () => {
      const { data, error } = await getItems({
        category: activeCategory !== 'all' ? activeCategory : undefined,
        search: search || undefined,
        maxPrice: maxPrice ? Number(maxPrice) : undefined,
        orderBy: sortBy,
        ascending: sortAsc,
      });
      if (error) throw error;
      return data;
    }
  });

  return (
    <div className="min-h-screen bg-background animate-in fade-in duration-500">
      <Navbar />
      <div className="container py-8">
        <h1 className="font-display text-3xl font-bold">Каталог</h1>
        <div className="mt-6 flex flex-col gap-4 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Поиск вещей..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
            {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2"><X className="h-4 w-4 text-muted-foreground" /></button>}
          </div>
          <div className="flex gap-2">
            <select
              value={`${sortBy}_${sortAsc}`}
              onChange={e => {
                const [col, asc] = e.target.value.split('_');
                setSortBy(col as typeof sortBy);
                setSortAsc(asc === 'true');
              }}
              className="rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="created_at_false">Новые</option>
              <option value="rating_false">По рейтингу</option>
              <option value="price_per_day_true">Дешевле</option>
              <option value="price_per_day_false">Дороже</option>
            </select>
            <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)}>
              <SlidersHorizontal className="mr-2 h-4 w-4" />Фильтры
            </Button>
          </div>
        </div>

        {showFilters && (
          <div className="mt-4 flex items-center gap-4 rounded-xl border bg-card p-4">
            <div className="flex items-center gap-2">
              <label className="text-sm text-muted-foreground whitespace-nowrap">Макс. цена/сутки:</label>
              <Input type="number" placeholder="5000" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} className="w-32" />
              <span className="text-sm text-muted-foreground">₽</span>
            </div>
            {maxPrice && <Button variant="ghost" size="sm" onClick={() => setMaxPrice('')}>Сбросить</Button>}
          </div>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          <button onClick={() => setSearchParams({})} className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${activeCategory === 'all' ? 'bg-primary text-primary-foreground border-primary' : 'bg-card text-muted-foreground hover:text-foreground border-border'}`}>Все</button>
          {CATEGORIES.map(cat => (
            <button key={cat.id} onClick={() => setSearchParams({ category: cat.id })} className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${activeCategory === cat.id ? 'bg-primary text-primary-foreground border-primary' : 'bg-card text-muted-foreground hover:text-foreground border-border'}`}>
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="flex flex-col space-y-3">
                <Skeleton className="h-[200px] w-full rounded-xl" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <>
            <p className="mt-4 text-sm text-muted-foreground">{items.length} объявлений</p>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {items.map(item => <ItemCard key={item.id} item={item} />)}
            </div>
            {items.length === 0 && (
              <div className="py-20 text-center text-muted-foreground">Ничего не найдено. Попробуйте изменить фильтры.</div>
            )}
          </>
        )}
      </div>
      <Footer />
    </div>
  );
};
export default Catalog;