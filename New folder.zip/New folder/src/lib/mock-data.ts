// Backward compat - real data now lives in store.ts
export { getItems as mockItems } from "@/lib/store";

export const categories = [
  { id: "tools", name: "Инструменты", icon: "🔧", count: 0 },
  { id: "sports", name: "Спорт", icon: "⚽", count: 0 },
  { id: "kids", name: "Детские товары", icon: "👶", count: 0 },
  { id: "events", name: "Для мероприятий", icon: "🎉", count: 0 },
  { id: "electronics", name: "Техника", icon: "📷", count: 0 },
  { id: "household", name: "Бытовая техника", icon: "🏠", count: 0 },
];
