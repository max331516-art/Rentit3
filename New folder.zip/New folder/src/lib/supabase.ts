import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { storage: localStorage, persistSession: true, autoRefreshToken: true },
});

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Profile {
  id: string;
  name: string;
  phone: string | null;
  avatar_url: string | null;
  telegram_id: number | null;
  telegram_username: string | null;
  rating: number;
  rentals_count: number;
  listings_count: number;
  created_at: string;
}

export interface Item {
  id: string;
  owner_id: string;
  title: string;
  category: string;
  description: string | null;
  price_per_day: number;
  deposit: number;
  min_days: number;
  images: string[];
  location: string | null;
  condition: string;
  available: boolean;
  rating: number;
  reviews_count: number;
  created_at: string;
  owner?: Profile;
}

export interface Booking {
  id: string;
  item_id: string;
  item_title: string;
  item_image: string | null;
  renter_id: string;
  owner_id: string;
  start_date: string;
  end_date: string;
  days: number;
  price_per_day: number;
  deposit: number;
  total_rent: number;
  platform_fee: number;
  total_amount: number;
  status: 'pending' | 'confirmed' | 'active' | 'returned' | 'cancelled' | 'disputed';
  created_at: string;
  renter?: Profile;
  owner?: Profile;
}

export interface Review {
  id: string;
  booking_id: string;
  item_id: string;
  reviewer_id: string;
  rating: number;
  text: string;
  created_at: string;
  reviewer?: Profile;
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

export async function signUp(email: string, password: string, name: string, phone: string) {
  return supabase.auth.signUp({ email, password, options: { data: { name, phone } } });
}

export async function signIn(email: string, password: string) {
  return supabase.auth.signInWithPassword({ email, password });
}

export async function signOut() {
  return supabase.auth.signOut();
}

// ─── Telegram Auth ────────────────────────────────────────────────────────────
// Для TMA: создаём анонимного пользователя и привязываем Telegram ID к профилю

export async function signInWithTelegram(telegramUser: {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
}) {
  const name = [telegramUser.first_name, telegramUser.last_name].filter(Boolean).join(' ');
  const email = `tg_${telegramUser.id}@rentit.tg`;
  const password = `tg_${telegramUser.id}_${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.slice(0, 8)}`;

  // Попробовать войти
  let { data, error } = await supabase.auth.signInWithPassword({ email, password });

  // Если нет — зарегистрировать
  if (error) {
    const reg = await supabase.auth.signUp({
      email, password,
      options: {
        data: {
          name,
          telegram_id: telegramUser.id,
          telegram_username: telegramUser.username ?? null,
          avatar_url: telegramUser.photo_url ?? null,
        }
      }
    });
    data = reg.data;
    error = reg.error;
  }

  // Обновить профиль с Telegram данными
  if (data?.user) {
    await supabase.from('profiles').upsert({
      id: data.user.id,
      name,
      telegram_id: telegramUser.id,
      telegram_username: telegramUser.username ?? null,
      avatar_url: telegramUser.photo_url ?? null,
    }, { onConflict: 'id' });
  }

  return { data, error };
}

// ─── Profiles ─────────────────────────────────────────────────────────────────

export async function getProfile(id: string): Promise<Profile | null> {
  try {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle();
    if (error) {
      console.error('Error fetching profile:', error);
      return null;
    }
    return data;
  } catch (err) {
    console.error('Unexpected error fetching profile:', err);
    return null;
  }
}

// ─── Photo Upload ─────────────────────────────────────────────────────────────

export async function uploadItemPhoto(file: File, userId: string): Promise<string | null> {
  try {
    const ext = file.name.split('.').pop() ?? 'jpg';
    const path = `${userId}/${Date.now()}.${ext}`;

    const { error } = await supabase.storage
      .from('item-photos')
      .upload(path, file, { cacheControl: '3600', upsert: false });

    if (error) {
      console.error('Upload error:', error);
      // If bucket doesn't exist, we can't do much from client side without admin keys
      // but we can log it clearly
      return null;
    }

    const { data } = supabase.storage.from('item-photos').getPublicUrl(path);
    return data.publicUrl;
  } catch (err) {
    console.error('Unexpected error in uploadItemPhoto:', err);
    return null;
  }
}

export async function deleteItemPhoto(url: string) {
  try {
    const path = url.split('/item-photos/')[1];
    if (!path) return;
    await supabase.storage.from('item-photos').remove([path]);
  } catch (err) {
    console.error('Error deleting photo:', err);
  }
}

// ─── Items ────────────────────────────────────────────────────────────────────

export async function getItems(opts?: {
  category?: string;
  search?: string;
  maxPrice?: number;
  orderBy?: 'price_per_day' | 'rating' | 'created_at';
  ascending?: boolean;
}) {
  let query = supabase
    .from('items')
    .select('*, owner:profiles!items_owner_id_fkey(*)')
    .eq('available', true);

  if (opts?.category) query = query.eq('category', opts.category);
  if (opts?.search) query = query.ilike('title', `%${opts.search}%`);
  if (opts?.maxPrice) query = query.lte('price_per_day', opts.maxPrice);

  query = query.order(opts?.orderBy ?? 'created_at', { ascending: opts?.ascending ?? false });

  const { data, error } = await query;
  return { data: (data ?? []) as Item[], error };
}

export async function getItemById(id: string) {
  const { data, error } = await supabase
    .from('items')
    .select('*, owner:profiles!items_owner_id_fkey(*)')
    .eq('id', id)
    .single();
  return { data: data as Item | null, error };
}

export async function createItem(item: Omit<Item, 'id' | 'rating' | 'reviews_count' | 'created_at' | 'owner'>) {
  try {
    // Check if profile exists, if not - create it using upsert to avoid race conditions
    const { error: profileError } = await supabase
      .from('profiles')
      .upsert({
        id: item.owner_id,
        name: 'Пользователь',
      }, { onConflict: 'id' });
    
    if (profileError) {
      console.error('Profile upsert error:', profileError);
    }

    // Insert item
    const { data, error } = await supabase.from('items').insert(item).select().single();
    if (error) {
      console.error('Item insertion error:', error);
    }
    return { data: data as Item | null, error };
  } catch (err) {
    console.error('Unexpected error in createItem:', err);
    return { data: null, error: err };
  }
}

export async function updateItem(id: string, patch: Partial<Item>) {
  const { data, error } = await supabase.from('items').update(patch).eq('id', id).select().single();
  return { data: data as Item | null, error };
}

export async function getItemsByOwner(ownerId: string) {
  const { data, error } = await supabase
    .from('items').select('*').eq('owner_id', ownerId).order('created_at', { ascending: false });
  return { data: (data ?? []) as Item[], error };
}

export async function isItemAvailable(itemId: string, startDate: string, endDate: string) {
  const { data } = await supabase
    .from('bookings').select('id').eq('item_id', itemId)
    .not('status', 'in', '("cancelled","returned")')
    .lte('start_date', endDate).gte('end_date', startDate);
  return !data || data.length === 0;
}

// ─── Bookings ─────────────────────────────────────────────────────────────────

export async function createBooking(booking: Omit<Booking, 'id' | 'created_at' | 'renter' | 'owner'>) {
  const { data, error } = await supabase.from('bookings').insert(booking).select().single();
  return { data: data as Booking | null, error };
}

export async function getBookingById(id: string) {
  const { data, error } = await supabase
    .from('bookings')
    .select('*, renter:profiles!bookings_renter_id_fkey(*), owner:profiles!bookings_owner_id_fkey(*)')
    .eq('id', id).single();
  return { data: data as Booking | null, error };
}

export async function updateBookingStatus(id: string, status: Booking['status']) {
  const { data, error } = await supabase.from('bookings').update({ status }).eq('id', id).select().single();
  return { data: data as Booking | null, error };
}

export async function getBookingsByRenter(renterId: string) {
  const { data, error } = await supabase
    .from('bookings').select('*').eq('renter_id', renterId).order('created_at', { ascending: false });
  return { data: (data ?? []) as Booking[], error };
}

export async function getBookingsByOwner(ownerId: string) {
  const { data, error } = await supabase
    .from('bookings').select('*').eq('owner_id', ownerId).order('created_at', { ascending: false });
  return { data: (data ?? []) as Booking[], error };
}

// ─── Reviews ──────────────────────────────────────────────────────────────────

export async function getReviewsByItem(itemId: string) {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, reviewer:profiles!reviews_reviewer_id_fkey(*)')
    .eq('item_id', itemId).order('created_at', { ascending: false });
  return { data: (data ?? []) as Review[], error };
}

export async function createReview(review: Omit<Review, 'id' | 'created_at' | 'reviewer'>) {
  const { data, error } = await supabase.from('reviews').insert(review).select().single();
  return { data: data as Review | null, error };
}

export async function hasReviewedBooking(bookingId: string, reviewerId: string) {
  const { data } = await supabase.from('reviews')
    .select('id').eq('booking_id', bookingId).eq('reviewer_id', reviewerId).single();
  return !!data;
}

// ─── Seed demo items ──────────────────────────────────────────────────────────

export async function seedDemoItems(ownerId: string) {
  const { data: existing } = await supabase.from('items').select('id').limit(1);
  if (existing && existing.length > 0) return;

  const items = [
    { owner_id: ownerId, title: 'Перфоратор Bosch GBH 2-26', category: 'tools', description: 'Профессиональный перфоратор. Полный комплект свёрл в кейсе. Три режима работы.', price_per_day: 500, deposit: 5000, min_days: 1, images: ['https://images.unsplash.com/photo-1504148455328-c376907d081c?w=600&q=80'], location: 'Москва, м. Таганская', condition: 'Отличное', available: true },
    { owner_id: ownerId, title: 'Горный велосипед Trek X-Caliber 8', category: 'sports', description: 'Велосипед 29", рама L. Гидравлические тормоза Shimano, 11 скоростей.', price_per_day: 1200, deposit: 15000, min_days: 1, images: ['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80'], location: 'Москва, м. Парк Культуры', condition: 'Хорошее', available: true },
    { owner_id: ownerId, title: 'Детская коляска Bugaboo Fox 3', category: 'kids', description: 'Люлька, прогулочный блок, дождевик в комплекте. Для детей 0–4 лет.', price_per_day: 800, deposit: 10000, min_days: 3, images: ['https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=600&q=80'], location: 'Москва, м. Бауманская', condition: 'Отличное', available: true },
    { owner_id: ownerId, title: 'Проектор Epson EH-TW750', category: 'electronics', description: 'Full HD, 3300 лм. HDMI, USB, Wi-Fi. Идеально для кино или презентаций.', price_per_day: 1500, deposit: 12000, min_days: 1, images: ['https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=600&q=80'], location: 'Москва, м. Тверская', condition: 'Отличное', available: true },
    { owner_id: ownerId, title: 'Шуруповёрт Makita DDF484', category: 'tools', description: 'Аккумуляторный 18V. Два аккумулятора + зарядная станция.', price_per_day: 400, deposit: 4000, min_days: 1, images: ['https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=600&q=80'], location: 'Москва, м. Сокольники', condition: 'Хорошее', available: true },
    { owner_id: ownerId, title: 'Палатка Outwell Nevada 4-местная', category: 'sports', description: 'Семейная палатка. Быстрая сборка, тент, колышки в комплекте.', price_per_day: 700, deposit: 6000, min_days: 2, images: ['https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=600&q=80'], location: 'Москва, м. Речной вокзал', condition: 'Хорошее', available: true },
    { owner_id: ownerId, title: 'Sony A7III + 28-70mm', category: 'electronics', description: 'Полнокадровая беззеркалка. 2 аккума, зарядка, сумка в комплекте.', price_per_day: 2500, deposit: 60000, min_days: 1, images: ['https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&q=80'], location: 'Москва, м. Арбатская', condition: 'Отличное', available: true },
    { owner_id: ownerId, title: 'Байдарка Kolibri K-200T', category: 'sports', description: 'Двухместная надувная. Вёсла, насос, сумка-рюкзак в комплекте.', price_per_day: 1800, deposit: 20000, min_days: 2, images: ['https://images.unsplash.com/photo-1609953843819-e8c3e66d9ef2?w=600&q=80'], location: 'Москва, м. Тушинская', condition: 'Хорошее', available: true },
    { owner_id: ownerId, title: 'Генератор Honda EU22i', category: 'household', description: 'Тихий инверторный 2.2 кВт. Для дачи, кемпинга.', price_per_day: 2000, deposit: 25000, min_days: 1, images: ['https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80'], location: 'Москва, м. Домодедовская', condition: 'Отличное', available: true },
  ];

  await supabase.from('items').insert(items);
}