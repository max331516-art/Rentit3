import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Loader2 } from 'lucide-react';

interface Message {
  id: string;
  sender_id: string;
  text: string;
  created_at: string;
}

// Function to mask phone numbers and telegram links
function maskText(text: string) {
  // Mask phones: +7 999 123-45-67 -> +7 (XXX) XXX-XX-XX
  let masked = text.replace(/(\+?\d[\d\-\s()]{9,}\d)/g, '[Скрыто до оплаты]');
  // Mask links/telegram
  masked = masked.replace(/(@\w+|t\.me\/\w+|vk\.com\/\w+|wa\.me\/\w+)/gi, '[Скрыто до оплаты]');
  return masked;
}

export default function Chat({ bookingId, canViewContacts }: { bookingId: string, canViewContacts: boolean }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!bookingId || !user) return;
    
    const loadMessages = async () => {
      const { data } = await supabase.from('messages').select('*').eq('booking_id', bookingId).order('created_at', { ascending: true });
      if (data) setMessages(data as Message[]);
      setLoading(false);
      setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    };
    
    loadMessages();

    const channel = supabase.channel(`chat:${bookingId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `booking_id=eq.${bookingId}` }, (payload) => {
        setMessages(prev => [...prev, payload.new as Message]);
        setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [bookingId, user]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user) return;
    
    const newText = text.trim();
    setText('');
    
    await supabase.from('messages').insert({
      booking_id: bookingId,
      sender_id: user.id,
      text: newText
    });
  };

  if (loading) return <div className="p-4 flex justify-center"><Loader2 className="animate-spin h-6 w-6 text-muted-foreground" /></div>;

  return (
    <div className="flex flex-col h-[400px] border rounded-xl overflow-hidden bg-card">
      <div className="p-3 border-b bg-muted/40 font-medium text-sm">
        Чат по сделке
        {!canViewContacts && <span className="ml-2 text-xs text-muted-foreground font-normal">(Контакты скрыты до оплаты)</span>}
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
            Нет сообщений. Напишите первым!
          </div>
        ) : (
          messages.map(msg => {
            const isMe = msg.sender_id === user?.id;
            const displayText = canViewContacts ? msg.text : maskText(msg.text);
            return (
              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${isMe ? 'bg-primary text-primary-foreground rounded-br-sm' : 'bg-muted rounded-bl-sm'}`}>
                  {displayText}
                </div>
              </div>
            );
          })
        )}
        <div ref={scrollRef} />
      </div>
      
      <form onSubmit={sendMessage} className="p-3 border-t bg-background flex gap-2">
        <Input 
          value={text} 
          onChange={e => setText(e.target.value)} 
          placeholder="Написать сообщение..." 
          className="flex-1"
        />
        <Button type="submit" size="icon" disabled={!text.trim()}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}