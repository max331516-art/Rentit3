import { useEffect, useRef, useState } from 'react';

declare global {
  interface Window {
    ymaps: any;
  }
}

interface MapPickerProps {
  onLocationSelect: (address: string) => void;
  defaultAddress?: string;
}

export default function MapPicker({ onLocationSelect, defaultAddress }: MapPickerProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const checkYmaps = setInterval(() => {
      if (window.ymaps) {
        clearInterval(checkYmaps);
        window.ymaps.ready(() => setIsLoaded(true));
      }
    }, 500);
    return () => clearInterval(checkYmaps);
  }, []);

  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    const map = new window.ymaps.Map(mapRef.current, {
      center: [55.751244, 37.618423], // Moscow
      zoom: 10,
      controls: ['zoomControl', 'searchControl']
    });

    const searchControl = map.controls.get('searchControl');
    
    map.events.add('click', async (e: any) => {
      const coords = e.get('coords');
      const res = await window.ymaps.geocode(coords);
      const firstGeoObject = res.geoObjects.get(0);
      const address = firstGeoObject.getAddressLine();
      onLocationSelect(address);
      
      map.geoObjects.removeAll();
      map.geoObjects.add(new window.ymaps.Placemark(coords, {
        balloonContent: address
      }));
    });

    searchControl.events.add('resultselect', (e: any) => {
      const index = e.get('index');
      searchControl.getResult(index).then((res: any) => {
        const address = res.getAddressLine();
        onLocationSelect(address);
      });
    });

    return () => {
      if (map) map.destroy();
    };
  }, [isLoaded, onLocationSelect]);

  return (
    <div className="space-y-2">
      <div 
        ref={mapRef} 
        className="h-[300px] w-full rounded-xl border bg-muted flex items-center justify-center overflow-hidden"
      >
        {!isLoaded && <div className="text-sm text-muted-foreground italic">Загрузка карты...</div>}
      </div>
      <p className="text-xs text-muted-foreground italic">
        Кликните на карту или используйте поиск, чтобы выбрать местоположение
      </p>
    </div>
  );
}