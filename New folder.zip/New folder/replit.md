# RentIt - P2P Rental Platform

## Overview

RentIt is a peer-to-peer rental marketplace where users can list personal items for rent and book items from others. Think "Airbnb for things" — users can rent out tools, sports equipment, electronics, kids' items, event supplies, and household appliances. The platform includes deposit protection, photo documentation of item condition, a booking workflow with status management, real-time chat between parties, and review/rating systems.

The app is built as a React SPA with Supabase as the backend (auth, database, storage, real-time). It also supports running as a Telegram Mini App (TMA) with native Telegram authentication and a bottom navigation bar.

The UI is in Russian (Russian-speaking target audience).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React 18 with TypeScript, bundled with Vite (using SWC for fast compilation)
- **Routing**: React Router v6 with these main routes:
  - `/` — Landing page with hero, categories, and recent items
  - `/catalog` — Searchable/filterable item catalog
  - `/item/:id` — Item detail with booking form
  - `/create` — Create new listing (with photo upload and Yandex Maps location picker)
  - `/booking/:id` — Booking detail page with status workflow and real-time chat
  - `/dashboard` — User dashboard (my rentals, my bookings, my listings)
  - `/how-it-works` — Static informational page
- **UI Components**: shadcn/ui component library (Radix UI primitives + Tailwind CSS). Components live in `src/components/ui/`. Custom theme with CSS variables for light/dark mode support via `next-themes`.
- **Styling**: Tailwind CSS with custom design tokens (green primary color `hsl(168, 55%, 38%)`, orange accent). Custom fonts: Inter (body) and Space Grotesk (headings).
- **State Management**: React Query (`@tanstack/react-query`) for server state; React Context for auth state (`src/contexts/AuthContext.tsx`).
- **Maps**: Yandex Maps API v2.1 for location picking when creating listings (`src/components/MapPicker.tsx`). The API script is loaded in `index.html`.

### Backend (Supabase)
- **Authentication**: Supabase Auth with email/password. Also supports Telegram Mini App auto-authentication via `signInWithTelegram()`.
- **Database**: PostgreSQL via Supabase. Key tables: `profiles`, `items`, `bookings`, `reviews`, `messages`. The schema is defined in `supabase/migrations/001_initial_schema.sql`.
- **Storage**: Supabase Storage bucket `item-photos` for item listing images.
- **Real-time**: Supabase Realtime channels for live chat in the booking page (`postgres_changes` on the `messages` table).
- **Drizzle Config**: There's a `drizzle.config.ts` pointing to `shared/schema.ts` and `DATABASE_URL` env var for PostgreSQL. This is set up for potential server-side usage but the current app primarily uses the Supabase JS client directly. When provisioning a database on Replit, ensure `DATABASE_URL` is set.

### Telegram Mini App (TMA) Support
- Detected via `window.Telegram.WebApp` in `src/hooks/useTelegram.ts`
- When running as TMA: hides the web navbar, shows a native-style bottom tab navigation (`TMABottomNav`), auto-authenticates using Telegram user data
- Uses Telegram WebApp SDK for haptic feedback, back button, and main button integration

### Booking Workflow
Items go through a status flow: `pending` → `confirmed` → `active` → `returned` (or `cancelled`/`disputed`). The chat component masks phone numbers and contact info until booking is paid.

### Key Files
- `src/lib/supabase.ts` — Supabase client, all API functions (CRUD for items, bookings, reviews, profiles), type definitions
- `src/lib/store.ts` — Local/mock data types and store (used as fallback/legacy)
- `src/contexts/AuthContext.tsx` — Auth state provider, handles both web and TMA auth flows
- `src/hooks/useTelegram.ts` — Telegram WebApp detection and user extraction
- `vite.config.ts` — Dev server configured on port 5000, host 0.0.0.0

### Build System
- **Dev**: `npm run dev` (Vite dev server on port 5000)
- **Build**: `npm run build` (Vite production build)
- **Tests**: Vitest with jsdom environment, `npm test`
- There's also a `script/build.ts` for building a server bundle with esbuild (for a potential Express server setup), but the primary app is client-side only

## External Dependencies

### Supabase
- **URL**: Configured via `VITE_SUPABASE_URL` environment variable
- **Anon Key**: Configured via `VITE_SUPABASE_PUBLISHABLE_KEY` environment variable
- Provides: PostgreSQL database, authentication, file storage, real-time subscriptions
- Database migration must be run manually via Supabase SQL Editor (see `SETUP.md`)

### Yandex Maps API
- Loaded via script tag in `index.html` with API key `79666063-de01-4601-90be-0bc0cf666063`
- Used for interactive location selection when creating listings

### Telegram Mini App SDK
- `@telegram-apps/sdk-react` and `@telegram-apps/telegram-ui` packages
- Enables running inside Telegram as a mini app with native integration

### PostgreSQL (Drizzle)
- `drizzle.config.ts` expects a `DATABASE_URL` environment variable
- Schema file at `shared/schema.ts`
- Migrations output to `./migrations` directory
- This may need a Postgres database provisioned on Replit if server-side features are added

### Key NPM Packages
- `react-router-dom` — Client-side routing
- `@tanstack/react-query` — Data fetching and caching
- `@supabase/supabase-js` — Supabase client
- `next-themes` — Dark/light theme switching
- `react-day-picker` — Date picker for booking
- `embla-carousel-react` — Image carousel
- `recharts` — Charts (available but may not be actively used)
- `vaul` — Drawer component
- `lucide-react` — Icon library
- `date-fns` — Date formatting utilities
- `zod` — Schema validation