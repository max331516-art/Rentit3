import { useParams, Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, CreditCard, Shield, Camera, CheckCircle, Clock, Truck, RotateCcw, AlertTriangle, Loader2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { getBookingById, updateBookingStatus, createReview, hasReviewedBooking, type Booking } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const STATUS_META: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending:   { label: 'Ожидает оплаты',        color: 'bg-yellow-100 text-yellow-800 border-yellow-200', icon: <Clock className="h-4 w-4" /> },
  confirmed: { label: 'Оплачено',              color: 'bg-blue-100 text-blue-800 border-blue-200',   icon: <CheckCircle className="h-4 w-4" /> },
  active:    { label: 'Активная аренда',        color: 'bg-green-100 text-green-800 border-green-200',  icon: <Truck className="h-4 w-4" /> },
  returned:  { label: 'Завершена',             color: 'bg-gray-100 text-gray-700 border-gray-200',   icon: <RotateCcw className="h-4 w-4" /> },
  cancelled: { label: 'Отменено',              color: 'bg-red-100 text-red-800 border-red-200',     icon: <AlertTriangle className="h-4 w-4" /> },
  disputed:  { label: 'Спор',                  color: 'bg-orange-100 text-orange-800 border-orange-200', icon: <AlertTriangle className="h-4 w-4" /> },
};

const BookingPage = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [paying, setPaying] = useState(false);
  const [alreadyReviewed, setAlreadyReviewed] = useState(false);
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const refresh = async () => {
    if (!id) return;
    const { data } = await getBookingById(id);
    setBooking(data);
  };

  useEffect(() => {
    if (!id) return;
    getBookingById(id).then(({ data }) => {
      setBooking(data);
      setLoading(false);
      if (data && user) {
        hasReviewedBooking(data.id, user.id).then(setAlreadyReviewed);
      }
    });
  }, [id, user]);

  if (loading) return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-20 flex justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
      <Footer />
    </div>
  );

  if (!booking || !user || (user.id !== booking.renter_id && user.id !== booking.owner_id)) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center"><h1 className="text-2xl font-bold">Нет доступа</h1></div>
        <Footer />
      </div>
    );
  }

  const isRenter = user.id === booking.renter_id;
  const isOwner = user.id === booking.owner_id;
  const st = STATUS_META[booking.status] ?? STATUS_META.pending;

  const doAction = async (newStatus: Booking['status']) => {
    setActionLoading(true);
    const { error } = await updateBookingStatus(booking.id, newStatus);
    if (error) toast({ title: 'Ошибка', description: error.message, variant: 'destructive' });
    else await refresh();
    setActionLoading(false);
  };

  const handlePay = () => {
    setPaying(true);
    setTimeout(async () => {
      await doAction('confirmed');
      setPaying(false);
      toast({ title: 'Оплата прошла!', description: 'Свяжитесь с владельцем для получения вещи.' });
    }, 1500);
  };

  const handleReview = async () => {
    if (!reviewText.trim()) { toast({ title: 'Напишите отзыв', variant: 'destructive' }); return; }
    setActionLoading(true);
    const { error } = await createReview({
      booking_id: booking.id,
      item_id: booking.item_id,
      reviewer_id: user.id,
      rating: reviewRating,
      text: reviewText,
    });
    setActionLoading(false);
    if (error) { toast({ title: 'Ошибка', description: error.message, variant: 'destructive' }); return; }
    setReviewSubmitted(true);
    setAlreadyReviewed(true);
    toast({ title: 'Отзыв опубликован!' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container max-w-2xl py-8">
        <Link to="/dashboard" className="mb-6 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" />Личный кабинет
        </Link>

        <div className="rounded-xl border bg-card p-6 card-shadow">
          <div className="flex items-start gap-4">
            <img src={booking.item_image || '/placeholder.svg'} alt={booking.item_title} className="h-20 w-20 rounded-lg object-cover flex-shrink-0" onError={e => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }} />
            <div className="flex-1 min-w-0">
              <h1 className="font-display text-xl font-bold truncate">{booking.item_title}</h1>
              <p className="text-sm text-muted-foreground mt-1">{booking.start_date} — {booking.end_date} ({booking.days} дн.)</p>
              <p className="text-xs text-muted-foreground mt-0.5">{isRenter ? `Владелец: ${booking.owner?.name ?? '—'}` : `Арендатор: ${booking.renter?.name ?? '—'}`}</p>
            </div>
            <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium flex-shrink-0 ${st.color}`}>
              {st.icon}{st.label}
            </span>
          </div>

          <div className="mt-6 rounded-lg border bg-muted/40 p-4 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">{booking.price_per_day} ₽ × {booking.days} дн.</span><span>{booking.total_rent.toLocaleString()} ₽</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Комиссия 15%</span><span>{booking.platform_fee.toLocaleString()} ₽</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Депозит</span><span>{booking.deposit.toLocaleString()} ₽</span></div>
            <div className="flex justify-between border-t pt-2 font-bold text-base"><span>Итого</span><span>{booking.total_amount.toLocaleString()} ₽</span></div>
          </div>

          <div className="mt-6 space-y-3">
            {isRenter && booking.status === 'pending' && (
              <>
                <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm text-blue-800">
                  <strong>Симуляция оплаты.</strong> В реальном продукте здесь будет подключён ЮKassa / Stripe.
                </div>
                <Button onClick={handlePay} disabled={paying} className="w-full bg-primary text-primary-foreground" size="lg">
                  {paying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-5 w-5" />}
                  {paying ? 'Обработка...' : `Оплатить ${booking.total_amount.toLocaleString()} ₽`}
                </Button>
                <Button onClick={() => doAction('cancelled')} variant="outline" className="w-full" disabled={actionLoading}>Отменить</Button>
              </>
            )}

            {isRenter && booking.status === 'confirmed' && (
              <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800">
                ✅ Оплата прошла. Свяжитесь с {booking.owner?.name} для получения вещи. Владелец подтвердит передачу.
              </div>
            )}

            {isOwner && booking.status === 'confirmed' && (
              <div>
                <p className="text-sm text-muted-foreground mb-3">Арендатор оплатил. Передайте вещь и подтвердите.</p>
                <Button onClick={() => doAction('active')} className="w-full bg-primary text-primary-foreground" size="lg" disabled={actionLoading}>
                  {actionLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Camera className="mr-2 h-5 w-5" />}
                  Подтвердить передачу
                </Button>
              </div>
            )}

            {isRenter && booking.status === 'active' && (
              <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800">
                🚀 Аренда активна. Верните вещь до {booking.end_date}. Владелец подтвердит возврат.
              </div>
            )}

            {isOwner && booking.status === 'active' && (
              <div>
                <p className="text-sm text-muted-foreground mb-3">Когда вещь вернут, подтвердите возврат.</p>
                <Button onClick={() => doAction('returned')} className="w-full bg-primary text-primary-foreground" size="lg" disabled={actionLoading}>
                  {actionLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RotateCcw className="mr-2 h-5 w-5" />}
                  Подтвердить возврат
                </Button>
              </div>
            )}

            {isRenter && booking.status === 'returned' && !alreadyReviewed && !reviewSubmitted && (
              <div className="rounded-xl border bg-muted/40 p-4">
                <h3 className="font-medium mb-3">Оставьте отзыв</h3>
                <div className="flex gap-1 mb-3">
                  {[1,2,3,4,5].map(s => (
                    <button key={s} onClick={() => setReviewRating(s)}>
                      <svg className={`h-7 w-7 ${s <= reviewRating ? 'fill-accent text-accent' : 'text-muted-foreground'}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" />
                      </svg>
                    </button>
                  ))}
                </div>
                <textarea value={reviewText} onChange={e => setReviewText(e.target.value)} rows={3} placeholder="Напишите отзыв..." className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
                <Button onClick={handleReview} disabled={actionLoading} className="mt-3 w-full bg-primary text-primary-foreground">
                  {actionLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Опубликовать отзыв
                </Button>
              </div>
            )}

            {(reviewSubmitted || (booking.status === 'returned' && alreadyReviewed)) && (
              <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-sm text-green-800">✅ Отзыв опубликован. Спасибо!</div>
            )}

            {booking.status === 'returned' && (
              <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm text-gray-700">
                <Shield className="inline h-4 w-4 mr-1 text-primary" />
                Аренда завершена. Депозит {booking.deposit.toLocaleString()} ₽ возвращён.
              </div>
            )}
            {booking.status === 'cancelled' && (
              <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">Бронирование отменено.</div>
            )}
          </div>
        </div>

        <div className="mt-4 text-center">
          <Link to={`/item/${booking.item_id}`} className="text-sm text-primary hover:underline">Посмотреть объявление</Link>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default BookingPage;