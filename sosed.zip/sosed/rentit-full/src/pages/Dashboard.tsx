import { Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Star, Plus, Package, ArrowRight, Loader2, Eye, EyeOff } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { useAuth } from '@/contexts/AuthContext';
import { getBookingsByRenter, getBookingsByOwner, getItemsByOwner, updateItem, type Booking, type Item } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

const STATUS_META: Record<string, { label: string; color: string }> = {
  pending:   { label: 'Ожидает оплаты', color: 'bg-yellow-100 text-yellow-800' },
  confirmed: { label: 'Оплачено',       color: 'bg-blue-100 text-blue-800' },
  active:    { label: 'Активная',       color: 'bg-green-100 text-green-800' },
  returned:  { label: 'Завершена',      color: 'bg-gray-100 text-gray-700' },
  cancelled: { label: 'Отменено',       color: 'bg-red-100 text-red-800' },
  disputed:  { label: 'Спор',           color: 'bg-orange-100 text-orange-800' },
};

function BookingRow({ booking }: { booking: Booking }) {
  const st = STATUS_META[booking.status] ?? STATUS_META.pending;
  return (
    <Link to={`/booking/${booking.id}`} className="block group">
      <div className="flex items-center gap-4 rounded-xl border bg-card p-4 card-shadow hover:border-primary/50 transition-colors">
        <img src={booking.item_image || '/placeholder.svg'} alt={booking.item_title} className="h-14 w-14 rounded-lg object-cover flex-shrink-0" onError={e => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }} />
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm truncate">{booking.item_title}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{booking.start_date} — {booking.end_date} · {booking.days} дн.</p>
          <p className="text-xs text-muted-foreground">{booking.total_amount.toLocaleString()} ₽</p>
        </div>
        <div className="flex flex-col items-end gap-2 flex-shrink-0">
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${st.color}`}>{st.label}</span>
          <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
      </div>
    </Link>
  );
}

function ItemRow({ item, onToggle }: { item: Item; onToggle: () => void }) {
  return (
    <div className="flex items-center gap-4 rounded-xl border bg-card p-4 card-shadow">
      <img src={item.images[0] || '/placeholder.svg'} alt={item.title} className="h-14 w-14 rounded-lg object-cover flex-shrink-0" onError={e => { (e.target as HTMLImageElement).src = '/placeholder.svg'; }} />
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{item.title}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{item.price_per_day} ₽/сутки · депозит {item.deposit.toLocaleString()} ₽</p>
        <div className="flex items-center gap-1 mt-0.5">
          <Star className="h-3 w-3 fill-accent text-accent" />
          <span className="text-xs text-muted-foreground">{item.rating > 0 ? `${item.rating} (${item.reviews_count})` : 'Нет отзывов'}</span>
        </div>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${item.available ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700'}`}>
          {item.available ? 'Активно' : 'Скрыто'}
        </span>
        <Link to={`/item/${item.id}`}>
          <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-4 w-4" /></Button>
        </Link>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onToggle} title={item.available ? 'Скрыть' : 'Показать'}>
          {item.available ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4 text-primary" />}
        </Button>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [renterBookings, setRenterBookings] = useState<Booking[]>([]);
  const [ownerBookings, setOwnerBookings] = useState<Booking[]>([]);
  const [myItems, setMyItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/'); return; }
    Promise.all([
      getBookingsByRenter(user.id),
      getBookingsByOwner(user.id),
      getItemsByOwner(user.id),
    ]).then(([{ data: rb }, { data: ob }, { data: items }]) => {
      setRenterBookings(rb);
      setOwnerBookings(ob);
      setMyItems(items);
      setLoading(false);
    });
  }, [user]);

  if (!user || loading) return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-20 flex justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
      <Footer />
    </div>
  );

  const toggleAvailability = async (item: Item) => {
    const { error } = await updateItem(item.id, { available: !item.available });
    if (error) { toast({ title: 'Ошибка', variant: 'destructive' }); return; }
    setMyItems(prev => prev.map(i => i.id === item.id ? { ...i, available: !i.available } : i));
    toast({ title: item.available ? 'Объявление скрыто' : 'Объявление активировано' });
  };

  const activeRenter = renterBookings.filter(b => ['pending','confirmed','active'].includes(b.status));
  const pastRenter = renterBookings.filter(b => ['returned','cancelled'].includes(b.status));
  const activeOwner = ownerBookings.filter(b => ['pending','confirmed','active'].includes(b.status));
  const pastOwner = ownerBookings.filter(b => ['returned','cancelled'].includes(b.status));

  const displayName = profile?.name ?? user.email?.split('@')[0] ?? '—';

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container py-8">
        <div className="flex items-center gap-5 rounded-2xl border bg-card p-6 card-shadow mb-8">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground text-2xl font-bold flex-shrink-0">
            {displayName.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1">
            <h1 className="font-display text-2xl font-bold">{displayName}</h1>
            <p className="text-sm text-muted-foreground">{user.email}{profile?.phone ? ` · ${profile.phone}` : ''}</p>
            <div className="flex items-center gap-4 mt-2 text-sm">
              {(profile?.rating ?? 0) > 0 && <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-accent text-accent" />{profile?.rating}</span>}
              <span className="text-muted-foreground">{profile?.rentals_count ?? 0} аренд</span>
              <span className="text-muted-foreground">{myItems.length} объявлений</span>
            </div>
          </div>
          <Link to="/create">
            <Button className="bg-primary text-primary-foreground"><Plus className="mr-2 h-4 w-4" />Добавить вещь</Button>
          </Link>
        </div>

        <Tabs defaultValue="renter">
          <TabsList className="mb-6">
            <TabsTrigger value="renter">Я арендую ({renterBookings.length})</TabsTrigger>
            <TabsTrigger value="owner">Мои аренды ({ownerBookings.length})</TabsTrigger>
            <TabsTrigger value="listings">Мои объявления ({myItems.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="renter">
            {activeRenter.length > 0 && <div className="mb-6"><p className="text-xs text-muted-foreground uppercase tracking-wide font-medium mb-3">Активные</p><div className="space-y-3">{activeRenter.map(b => <BookingRow key={b.id} booking={b} />)}</div></div>}
            {pastRenter.length > 0 && <div><p className="text-xs text-muted-foreground uppercase tracking-wide font-medium mb-3">История</p><div className="space-y-3">{pastRenter.map(b => <BookingRow key={b.id} booking={b} />)}</div></div>}
            {renterBookings.length === 0 && (
              <div className="py-16 text-center"><Package className="h-12 w-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">Вы ещё ничего не арендовали</p><Link to="/catalog"><Button className="mt-4 bg-primary text-primary-foreground">Посмотреть каталог</Button></Link></div>
            )}
          </TabsContent>

          <TabsContent value="owner">
            {activeOwner.length > 0 && <div className="mb-6"><p className="text-xs text-muted-foreground uppercase tracking-wide font-medium mb-3">Активные</p><div className="space-y-3">{activeOwner.map(b => <BookingRow key={b.id} booking={b} />)}</div></div>}
            {pastOwner.length > 0 && <div><p className="text-xs text-muted-foreground uppercase tracking-wide font-medium mb-3">История</p><div className="space-y-3">{pastOwner.map(b => <BookingRow key={b.id} booking={b} />)}</div></div>}
            {ownerBookings.length === 0 && <div className="py-16 text-center"><Package className="h-12 w-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">Ещё нет запросов на аренду</p></div>}
          </TabsContent>

          <TabsContent value="listings">
            {myItems.length > 0 ? (
              <div className="space-y-3">{myItems.map(i => <ItemRow key={i.id} item={i} onToggle={() => toggleAvailability(i)} />)}</div>
            ) : (
              <div className="py-16 text-center"><Package className="h-12 w-12 mx-auto text-muted-foreground mb-3" /><p className="text-muted-foreground">Нет объявлений</p><Link to="/create"><Button className="mt-4 bg-primary text-primary-foreground"><Plus className="mr-2 h-4 w-4" />Добавить вещь</Button></Link></div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  );
}