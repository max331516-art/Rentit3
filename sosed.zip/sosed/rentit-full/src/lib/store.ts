// ─── Types ────────────────────────────────────────────────────────────────────

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  avatar: string;
  phone: string;
  rating: number;
  rentalsCount: number;
  listingsCount: number;
  createdAt: string;
}

export interface Item {
  id: string;
  title: string;
  category: string;
  description: string;
  pricePerDay: number;
  deposit: number;
  minDays: number;
  images: string[];
  ownerId: string;
  ownerName: string;
  ownerAvatar: string;
  ownerRating: number;
  ownerRentalsCount: number;
  location: string;
  rating: number;
  reviewsCount: number;
  condition: string;
  available: boolean;
  createdAt: string;
}

export interface Booking {
  id: string;
  itemId: string;
  itemTitle: string;
  itemImage: string;
  renterId: string;
  renterName: string;
  ownerId: string;
  ownerName: string;
  startDate: string;
  endDate: string;
  days: number;
  pricePerDay: number;
  deposit: number;
  totalRent: number;
  platformFee: number;
  totalAmount: number;
  status: "pending" | "confirmed" | "active" | "returned" | "cancelled" | "disputed";
  photosBefore: string[];
  photosAfter: string[];
  createdAt: string;
}

export interface Review {
  id: string;
  bookingId: string;
  itemId: string;
  reviewerId: string;
  reviewerName: string;
  reviewerAvatar: string;
  rating: number;
  text: string;
  createdAt: string;
}

// ─── Simple hash ──────────────────────────────────────────────────────────────
function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return hash.toString(36);
}

// ─── Storage helpers ──────────────────────────────────────────────────────────
function getKey<T>(key: string, fallback: T): T {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : fallback;
  } catch {
    return fallback;
  }
}
function setKey<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

// ─── Seed data ────────────────────────────────────────────────────────────────
const SEED_USERS: User[] = [
  {
    id: "u1", name: "Алексей М.", email: "alexey@demo.ru",
    passwordHash: simpleHash("demo123"),
    avatar: "", phone: "+7 999 111 22 33",
    rating: 4.8, rentalsCount: 32, listingsCount: 4, createdAt: "2024-01-10",
  },
  {
    id: "u2", name: "Мария К.", email: "maria@demo.ru",
    passwordHash: simpleHash("demo123"),
    avatar: "", phone: "+7 999 222 33 44",
    rating: 4.6, rentalsCount: 15, listingsCount: 2, createdAt: "2024-02-15",
  },
  {
    id: "u3", name: "Дмитрий Л.", email: "dmitry@demo.ru",
    passwordHash: simpleHash("demo123"),
    avatar: "", phone: "+7 999 333 44 55",
    rating: 4.9, rentalsCount: 45, listingsCount: 6, createdAt: "2023-11-20",
  },
];

const SEED_ITEMS: Item[] = [
  {
    id: "i1", title: "Перфоратор Bosch GBH 2-26", category: "tools",
    description: "Профессиональный перфоратор в отличном состоянии. Полный комплект свёрл в кейсе. Три режима работы: сверление, сверление с ударом, долбление.",
    pricePerDay: 500, deposit: 5000, minDays: 1,
    images: ["https://images.unsplash.com/photo-1504148455328-c376907d081c?w=600&q=80"],
    ownerId: "u1", ownerName: "Алексей М.", ownerAvatar: "", ownerRating: 4.8, ownerRentalsCount: 32,
    location: "Москва, м. Таганская", rating: 4.9, reviewsCount: 18, condition: "Отличное", available: true, createdAt: "2024-03-01",
  },
  {
    id: "i2", title: "Горный велосипед Trek X-Caliber 8", category: "sports",
    description: "Горный велосипед 29 дюймов, размер рамы L. Гидравлические тормоза Shimano, 11 скоростей. Подходит для роста 180–190 см.",
    pricePerDay: 1200, deposit: 15000, minDays: 1,
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80"],
    ownerId: "u2", ownerName: "Мария К.", ownerAvatar: "", ownerRating: 4.6, ownerRentalsCount: 15,
    location: "Москва, м. Парк Культуры", rating: 4.7, reviewsCount: 12, condition: "Хорошее", available: true, createdAt: "2024-03-05",
  },
  {
    id: "i3", title: "Детская коляска Bugaboo Fox 3", category: "kids",
    description: "Премиальная коляска в комплекте: люлька, прогулочный блок, дождевик, москитная сетка. Чистая, ухоженная. Для детей 0–4 лет.",
    pricePerDay: 800, deposit: 10000, minDays: 3,
    images: ["https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=600&q=80"],
    ownerId: "u1", ownerName: "Алексей М.", ownerAvatar: "", ownerRating: 4.8, ownerRentalsCount: 32,
    location: "Москва, м. Бауманская", rating: 5.0, reviewsCount: 6, condition: "Отличное", available: true, createdAt: "2024-03-10",
  },
  {
    id: "i4", title: "Проектор Epson EH-TW750", category: "electronics",
    description: "Full HD проектор 3300 лм. HDMI, USB, Wi-Fi. Идеально для домашнего кинотеатра или презентаций. HDMI кабель в комплекте.",
    pricePerDay: 1500, deposit: 12000, minDays: 1,
    images: ["https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=600&q=80"],
    ownerId: "u3", ownerName: "Дмитрий Л.", ownerAvatar: "", ownerRating: 4.9, ownerRentalsCount: 45,
    location: "Москва, м. Тверская", rating: 4.8, reviewsCount: 28, condition: "Отличное", available: true, createdAt: "2024-02-20",
  },
  {
    id: "i5", title: "Шуруповёрт Makita DDF484", category: "tools",
    description: "Аккумуляторный шуруповёрт 18V. Два аккумулятора + зарядная станция. Крутящий момент 50 Нм, 21 режим.",
    pricePerDay: 400, deposit: 4000, minDays: 1,
    images: ["https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=600&q=80"],
    ownerId: "u1", ownerName: "Алексей М.", ownerAvatar: "", ownerRating: 4.8, ownerRentalsCount: 32,
    location: "Москва, м. Сокольники", rating: 4.6, reviewsCount: 14, condition: "Хорошее", available: true, createdAt: "2024-02-25",
  },
  {
    id: "i6", title: "Палатка Outwell Nevada 4-местная", category: "sports",
    description: "Семейная кемпинговая палатка. Быстрая сборка 10 мин, тент, алюминиевые колышки, ремкомплект. Водонепроницаемость 3000 мм.",
    pricePerDay: 700, deposit: 6000, minDays: 2,
    images: ["https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=600&q=80"],
    ownerId: "u2", ownerName: "Мария К.", ownerAvatar: "", ownerRating: 4.6, ownerRentalsCount: 15,
    location: "Москва, м. Речной вокзал", rating: 4.5, reviewsCount: 9, condition: "Хорошее", available: true, createdAt: "2024-03-15",
  },
  {
    id: "i7", title: "Фотоаппарат Sony A7III + 28-70mm", category: "electronics",
    description: "Полнокадровая беззеркальная камера. Объектив 28-70mm f/3.5-5.6, 2 аккумулятора, зарядка, сумка. Идеально для путешествий.",
    pricePerDay: 2500, deposit: 60000, minDays: 1,
    images: ["https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&q=80"],
    ownerId: "u3", ownerName: "Дмитрий Л.", ownerAvatar: "", ownerRating: 4.9, ownerRentalsCount: 45,
    location: "Москва, м. Арбатская", rating: 4.9, reviewsCount: 35, condition: "Отличное", available: true, createdAt: "2024-01-15",
  },
  {
    id: "i8", title: "Надувная байдарка Kolibri K-200T", category: "sports",
    description: "Двухместная надувная байдарка. Вёсла, насос, сумка-рюкзак в комплекте. Грузоподъёмность 220 кг.",
    pricePerDay: 1800, deposit: 20000, minDays: 2,
    images: ["https://images.unsplash.com/photo-1609953843819-e8c3e66d9ef2?w=600&q=80"],
    ownerId: "u2", ownerName: "Мария К.", ownerAvatar: "", ownerRating: 4.6, ownerRentalsCount: 15,
    location: "Москва, м. Тушинская", rating: 4.7, reviewsCount: 11, condition: "Хорошее", available: true, createdAt: "2024-03-20",
  },
  {
    id: "i9", title: "Генератор Honda EU22i 2.2 кВт", category: "household",
    description: "Тихий инверторный генератор, 2.2 кВт. Расход топлива 1 л/ч. Подходит для дачи, кемпинга. Бензин 95.",
    pricePerDay: 2000, deposit: 25000, minDays: 1,
    images: ["https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80"],
    ownerId: "u3", ownerName: "Дмитрий Л.", ownerAvatar: "", ownerRating: 4.9, ownerRentalsCount: 45,
    location: "Москва, м. Домодедовская", rating: 4.8, reviewsCount: 22, condition: "Отличное", available: true, createdAt: "2024-02-01",
  },
];

const SEED_REVIEWS: Review[] = [
  {
    id: "r1", bookingId: "b0", itemId: "i1", reviewerId: "u2", reviewerName: "Мария К.", reviewerAvatar: "",
    rating: 5, text: "Отличный перфоратор, всё работает как часы. Алексей быстро ответил и удобно организовал передачу.", createdAt: "2024-03-10",
  },
  {
    id: "r2", bookingId: "b0", itemId: "i1", reviewerId: "u3", reviewerName: "Дмитрий Л.", reviewerAvatar: "",
    rating: 5, text: "Брал на ремонт ванной — справился на отлично. Кейс со свёрлами — огонь.", createdAt: "2024-03-20",
  },
  {
    id: "r3", bookingId: "b0", itemId: "i4", reviewerId: "u1", reviewerName: "Алексей М.", reviewerAvatar: "",
    rating: 5, text: "Смотрели кино в гостях — все были в восторге. Качество картинки великолепное.", createdAt: "2024-03-25",
  },
  {
    id: "r4", bookingId: "b0", itemId: "i7", reviewerId: "u2", reviewerName: "Мария К.", reviewerAvatar: "",
    rating: 4, text: "Камера в отличном состоянии. Единственный минус — чехол немного потёрт, но на работе не сказывается.", createdAt: "2024-04-01",
  },
];

// ─── Init store ───────────────────────────────────────────────────────────────
function initStore() {
  if (!localStorage.getItem("rentit_initialized")) {
    setKey("rentit_users", SEED_USERS);
    setKey("rentit_items", SEED_ITEMS);
    setKey("rentit_bookings", [] as Booking[]);
    setKey("rentit_reviews", SEED_REVIEWS);
    localStorage.setItem("rentit_initialized", "1");
  }
}

// ─── Users ────────────────────────────────────────────────────────────────────
export function getUsers(): User[] {
  initStore();
  return getKey<User[]>("rentit_users", []);
}
export function saveUsers(users: User[]) { setKey("rentit_users", users); }

export function getUserById(id: string): User | undefined {
  return getUsers().find((u) => u.id === id);
}

export function registerUser(name: string, email: string, password: string, phone: string): User | null {
  const users = getUsers();
  if (users.find((u) => u.email === email)) return null;
  const user: User = {
    id: "u" + Date.now(),
    name, email, phone,
    passwordHash: simpleHash(password),
    avatar: "", rating: 0, rentalsCount: 0, listingsCount: 0,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  saveUsers([...users, user]);
  return user;
}

export function loginUser(email: string, password: string): User | null {
  const users = getUsers();
  return users.find((u) => u.email === email && u.passwordHash === simpleHash(password)) ?? null;
}

// ─── Current session ──────────────────────────────────────────────────────────
export function getCurrentUser(): User | null {
  const id = localStorage.getItem("rentit_session");
  if (!id) return null;
  return getUserById(id) ?? null;
}
export function setCurrentUser(user: User | null) {
  if (user) localStorage.setItem("rentit_session", user.id);
  else localStorage.removeItem("rentit_session");
}

// ─── Items ────────────────────────────────────────────────────────────────────
export function getItems(): Item[] {
  initStore();
  return getKey<Item[]>("rentit_items", []);
}
export function saveItems(items: Item[]) { setKey("rentit_items", items); }

export function getItemById(id: string): Item | undefined {
  return getItems().find((i) => i.id === id);
}

export function createItem(data: Omit<Item, "id" | "rating" | "reviewsCount" | "available" | "createdAt">): Item {
  const items = getItems();
  const item: Item = {
    ...data,
    id: "i" + Date.now(),
    rating: 0,
    reviewsCount: 0,
    available: true,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  saveItems([...items, item]);
  // update owner listing count
  const users = getUsers();
  saveUsers(users.map((u) => u.id === data.ownerId ? { ...u, listingsCount: u.listingsCount + 1 } : u));
  return item;
}

export function updateItem(id: string, patch: Partial<Item>) {
  saveItems(getItems().map((i) => i.id === id ? { ...i, ...patch } : i));
}

// ─── Bookings ─────────────────────────────────────────────────────────────────
export function getBookings(): Booking[] {
  initStore();
  return getKey<Booking[]>("rentit_bookings", []);
}
export function saveBookings(b: Booking[]) { setKey("rentit_bookings", b); }

export function getBookingById(id: string): Booking | undefined {
  return getBookings().find((b) => b.id === id);
}

export function createBooking(data: Omit<Booking, "id" | "status" | "photosBefore" | "photosAfter" | "createdAt">): Booking {
  const booking: Booking = {
    ...data,
    id: "bk" + Date.now(),
    status: "pending",
    photosBefore: [],
    photosAfter: [],
    createdAt: new Date().toISOString().slice(0, 10),
  };
  saveBookings([...getBookings(), booking]);
  return booking;
}

export function updateBooking(id: string, patch: Partial<Booking>) {
  saveBookings(getBookings().map((b) => b.id === id ? { ...b, ...patch } : b));
}

// ─── Reviews ──────────────────────────────────────────────────────────────────
export function getReviews(): Review[] {
  initStore();
  return getKey<Review[]>("rentit_reviews", []);
}
export function saveReviews(r: Review[]) { setKey("rentit_reviews", r); }

export function getReviewsForItem(itemId: string): Review[] {
  return getReviews().filter((r) => r.itemId === itemId);
}

export function createReview(data: Omit<Review, "id" | "createdAt">): Review {
  const review: Review = { ...data, id: "rv" + Date.now(), createdAt: new Date().toISOString().slice(0, 10) };
  saveReviews([...getReviews(), review]);
  // recalculate item rating
  const allItemReviews = [...getReviewsForItem(data.itemId), review];
  const avg = allItemReviews.reduce((s, r) => s + r.rating, 0) / allItemReviews.length;
  updateItem(data.itemId, { rating: Math.round(avg * 10) / 10, reviewsCount: allItemReviews.length });
  // update booking
  updateBooking(data.bookingId, { status: "returned" });
  return review;
}

// ─── Getters for dashboard ────────────────────────────────────────────────────
export function getBookingsForRenter(userId: string): Booking[] {
  return getBookings().filter((b) => b.renterId === userId);
}
export function getBookingsForOwner(userId: string): Booking[] {
  return getBookings().filter((b) => b.ownerId === userId);
}
export function getItemsForOwner(userId: string): Item[] {
  return getItems().filter((i) => i.ownerId === userId);
}

// ─── Booking conflict check ───────────────────────────────────────────────────
export function isItemAvailableForDates(itemId: string, start: string, end: string): boolean {
  const bookings = getBookings().filter(
    (b) => b.itemId === itemId && !["cancelled", "returned"].includes(b.status)
  );
  const s = new Date(start), e = new Date(end);
  for (const b of bookings) {
    const bs = new Date(b.startDate), be = new Date(b.endDate);
    if (s <= be && e >= bs) return false;
  }
  return true;
}
