import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { User, Session } from '@supabase/supabase-js';
import { supabase, getProfile, seedDemoItems, signInWithTelegram, type Profile } from '@/lib/supabase';
import { useTelegram } from '@/hooks/useTelegram';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  session: Session | null;
  loading: boolean;
  isTMA: boolean;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null, profile: null, session: null, loading: true, isTMA: false, refreshProfile: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const { isTMA, telegramUser, isReady } = useTelegram();

  const loadProfile = async (u: User) => {
    const p = await getProfile(u.id);
    setProfile(p);
    if (p) await seedDemoItems(u.id);
  };

  const refreshProfile = async () => {
    if (user) await loadProfile(user);
  };

  // Auto-auth via Telegram if in TMA
  useEffect(() => {
    if (!isReady) return;
    if (isTMA && telegramUser) {
      signInWithTelegram(telegramUser).then(({ data }) => {
        if (data?.user) {
          setUser(data.user);
          setSession(data.session ?? null);
          loadProfile(data.user).finally(() => setLoading(false));
        } else {
          setLoading(false);
        }
      });
    } else {
      // Normal web: use existing session
      supabase.auth.getSession().then(({ data: { session: s } }) => {
        setSession(s);
        setUser(s?.user ?? null);
        if (s?.user) loadProfile(s.user).finally(() => setLoading(false));
        else setLoading(false);
      });
    }
  }, [isReady, isTMA, telegramUser]);

  useEffect(() => {
    if (isTMA) return; // TMA handles auth separately
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadProfile(s.user);
      else setProfile(null);
    });
    return () => subscription.unsubscribe();
  }, [isTMA]);

  return (
    <AuthContext.Provider value={{ user, profile, session, loading, isTMA, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}