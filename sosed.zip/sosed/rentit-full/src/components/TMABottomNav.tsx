import { Link, useLocation } from 'react-router-dom';
import { Home, Search, Plus, User } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const tabs = [
  { path: '/',         icon: Home,   label: 'Главная' },
  { path: '/catalog',  icon: Search, label: 'Каталог' },
  { path: '/create',   icon: Plus,   label: 'Сдать' },
  { path: '/dashboard', icon: User,  label: 'Кабинет' },
];

export default function TMABottomNav() {
  const location = useLocation();
  const { isTMA } = useAuth();

  // Only show in TMA
  if (!isTMA) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card/95 backdrop-blur-md pb-safe">
      <div className="flex">
        {tabs.map(tab => {
          const active = location.pathname === tab.path;
          const Icon = tab.icon;
          return (
            <Link
              key={tab.path}
              to={tab.path}
              className={`flex flex-1 flex-col items-center gap-0.5 py-3 text-xs font-medium transition-colors ${
                active ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className={`flex h-6 w-6 items-center justify-center rounded-lg transition-all ${
                active ? 'bg-primary/10 scale-110' : ''
              } ${tab.label === 'Сдать' ? 'bg-primary text-primary-foreground rounded-full h-8 w-8 -mt-1' : ''}`}>
                <Icon className={`h-5 w-5 ${tab.label === 'Сдать' ? 'text-primary-foreground' : ''}`} />
              </div>
              {tab.label !== 'Сдать' && <span>{tab.label}</span>}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}