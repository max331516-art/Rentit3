import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { signIn, signUp } from '@/lib/supabase';
import { Loader2 } from 'lucide-react';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
}

export default function AuthModal({ open, onClose }: AuthModalProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const reset = () => { setName(''); setEmail(''); setPhone(''); setPassword(''); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) { toast({ title: 'Ошибка входа', description: error.message, variant: 'destructive' }); return; }
        toast({ title: 'Добро пожаловать!' });
        reset();
        onClose();
      } else {
        if (!name.trim()) { toast({ title: 'Введите имя', variant: 'destructive' }); return; }
        const { error } = await signUp(email, password, name, phone);
        if (error) { toast({ title: 'Ошибка регистрации', description: error.message, variant: 'destructive' }); return; }
        toast({ title: 'Регистрация прошла успешно!', description: 'Добро пожаловать в RentIt' });
        reset();
        onClose();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">
            {mode === 'login' ? 'Войти в RentIt' : 'Регистрация'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          {mode === 'register' && (
            <>
              <div className="space-y-1.5">
                <Label>Имя</Label>
                <Input value={name} onChange={e => setName(e.target.value)} placeholder="Иван Иванов" required />
              </div>
              <div className="space-y-1.5">
                <Label>Телефон</Label>
                <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+7 999 000 00 00" />
              </div>
            </>
          )}
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@email.ru" required />
          </div>
          <div className="space-y-1.5">
            <Label>Пароль</Label>
            <Input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required minLength={6} />
          </div>
          <Button type="submit" className="w-full bg-primary text-primary-foreground" disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            {mode === 'login' ? 'Войти' : 'Зарегистрироваться'}
          </Button>
        </form>
        <div className="text-center text-sm text-muted-foreground">
          {mode === 'login' ? (
            <>Нет аккаунта?{' '}
              <button onClick={() => setMode('register')} className="text-primary font-medium hover:underline">Зарегистрироваться</button>
            </>
          ) : (
            <>Уже есть аккаунт?{' '}
              <button onClick={() => setMode('login')} className="text-primary font-medium hover:underline">Войти</button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}