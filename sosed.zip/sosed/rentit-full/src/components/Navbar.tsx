import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Search, Plus, Menu, X, User, LogOut, LayoutDashboard } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import AuthModal from '@/components/AuthModal';
import { signOut } from '@/lib/supabase';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const { user, profile, isTMA } = useAuth();
  const navigate = useNavigate();

  // В Telegram Mini App навбар не показываем — TMA использует нативную навигацию
  if (isTMA) return null;

  const handleLogout = async () => { await signOut(); navigate('/'); };
  const displayName = profile?.name ?? user?.email?.split('@')[0] ?? 'Профиль';

  return (
    <>
      <nav className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-md">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <span className="text-lg font-bold text-primary-foreground">R</span>
            </div>
            <span className="font-display text-xl font-bold text-foreground">RentIt</span>
          </Link>
          <div className="hidden items-center gap-6 md:flex">
            <Link to="/catalog" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Каталог</Link>
            <Link to="/how-it-works" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">Как это работает</Link>
          </div>
          <div className="hidden items-center gap-3 md:flex">
            <Link to="/catalog"><Button variant="ghost" size="sm"><Search className="mr-2 h-4 w-4" />Поиск</Button></Link>
            {user ? (
              <>
                <Link to="/create"><Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90"><Plus className="mr-2 h-4 w-4" />Сдать вещь</Button></Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">{displayName.charAt(0).toUpperCase()}</div>
                      {displayName.split(' ')[0]}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={() => navigate('/dashboard')}><LayoutDashboard className="mr-2 h-4 w-4" />Личный кабинет</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-destructive"><LogOut className="mr-2 h-4 w-4" />Выйти</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Link to="/create"><Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90"><Plus className="mr-2 h-4 w-4" />Сдать вещь</Button></Link>
                <Button variant="outline" size="sm" onClick={() => setAuthOpen(true)}><User className="mr-2 h-4 w-4" />Войти</Button>
              </>
            )}
          </div>
          <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        {mobileOpen && (
          <div className="border-t bg-card p-4 md:hidden">
            <div className="flex flex-col gap-3">
              <Link to="/catalog" className="text-sm font-medium" onClick={() => setMobileOpen(false)}>Каталог</Link>
              <Link to="/how-it-works" className="text-sm font-medium" onClick={() => setMobileOpen(false)}>Как это работает</Link>
              {user && <Link to="/dashboard" className="text-sm font-medium" onClick={() => setMobileOpen(false)}>Личный кабинет</Link>}
              <Link to="/create" onClick={() => setMobileOpen(false)}><Button size="sm" className="w-full bg-primary text-primary-foreground"><Plus className="mr-2 h-4 w-4" />Сдать вещь</Button></Link>
              {user ? (
                <Button variant="outline" size="sm" className="w-full" onClick={() => { handleLogout(); setMobileOpen(false); }}>Выйти</Button>
              ) : (
                <Button variant="outline" size="sm" className="w-full" onClick={() => { setAuthOpen(true); setMobileOpen(false); }}>Войти</Button>
              )}
            </div>
          </div>
        )}
      </nav>
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
    </>
  );
}